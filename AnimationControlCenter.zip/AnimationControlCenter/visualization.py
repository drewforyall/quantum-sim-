import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
from typing import Dict, List, Any

class QuantumVisualizer:
    """
    Visualization components for quantum consciousness simulation.
    Creates interactive plots showing quantum state evolution, entanglement networks,
    observer effects, and EMF field interactions.
    """
    
    def __init__(self):
        self.color_palette = px.colors.qualitative.Set3
        
    def create_quantum_state_plot(self, state_data: Dict[str, Any], t: float) -> go.Figure:
        """Create a 3D visualization of quantum state evolution."""
        n_qubits = state_data['n_qubits']
        
        # Create subplots for different representations
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Bloch Spheres', 'Density Matrix (Real)', 
                          'Pauli Expectations', 'State Amplitudes'),
            specs=[[{"type": "scatter3d"}, {"type": "heatmap"}],
                   [{"type": "bar"}, {"type": "scatter"}]]
        )
        
        # Bloch sphere representation
        for i in range(min(n_qubits, 2)):  # Show up to 2 Bloch spheres
            pauli_x = state_data['pauli_expectations'].get(f'qubit_{i}_X', 0)
            pauli_y = state_data['pauli_expectations'].get(f'qubit_{i}_Y', 0)
            pauli_z = state_data['pauli_expectations'].get(f'qubit_{i}_Z', 0)
            
            # Bloch vector
            fig.add_trace(
                go.Scatter3d(
                    x=[0, pauli_x], y=[0, pauli_y], z=[0, pauli_z],
                    mode='lines+markers',
                    name=f'Qubit {i+1}',
                    line=dict(color=self.color_palette[i], width=8),
                    marker=dict(size=[3, 8], color=self.color_palette[i])
                ),
                row=1, col=1
            )
        
        # Add Bloch sphere wireframe
        u = np.linspace(0, 2 * np.pi, 20)
        v = np.linspace(0, np.pi, 20)
        x_sphere = np.outer(np.cos(u), np.sin(v))
        y_sphere = np.outer(np.sin(u), np.sin(v))
        z_sphere = np.outer(np.ones(np.size(u)), np.cos(v))
        
        fig.add_trace(
            go.Surface(x=x_sphere, y=y_sphere, z=z_sphere, 
                      opacity=0.1, showscale=False, 
                      colorscale='Blues', name='Bloch Sphere'),
            row=1, col=1
        )
        
        # Density matrix heatmap (real part)
        rho_real = np.real(state_data['density_matrix'])
        fig.add_trace(
            go.Heatmap(z=rho_real, colorscale='RdBu', name='ρ (Real)'),
            row=1, col=2
        )
        
        # Pauli expectations bar chart
        pauli_names = []
        pauli_values = []
        for key, value in state_data['pauli_expectations'].items():
            pauli_names.append(key.replace('qubit_', 'Q').replace('_', ' '))
            pauli_values.append(value)
        
        fig.add_trace(
            go.Bar(x=pauli_names, y=pauli_values, 
                  marker_color=self.color_palette[:len(pauli_values)]),
            row=2, col=1
        )
        
        # State amplitudes/probabilities
        eigenvals = state_data['eigenvalues']
        state_indices = list(range(len(eigenvals)))
        
        fig.add_trace(
            go.Scatter(x=state_indices, y=eigenvals, mode='markers+lines',
                      marker=dict(size=10, color='red'),
                      name='Eigenvalues'),
            row=2, col=2
        )
        
        # Update layout
        fig.update_layout(
            title=f'Quantum State at t = {t:.3f}',
            showlegend=True,
            height=600
        )
        
        # Update 3D scene
        fig.update_scenes(
            xaxis_title="⟨σₓ⟩", yaxis_title="⟨σᵧ⟩", zaxis_title="⟨σᵤ⟩",
            xaxis=dict(range=[-1.1, 1.1]),
            yaxis=dict(range=[-1.1, 1.1]),
            zaxis=dict(range=[-1.1, 1.1])
        )
        
        return fig
    
    def create_entanglement_network(self, state_data: Dict[str, Any], 
                                   params: Dict[str, Any]) -> go.Figure:
        """Create a network visualization of qubit entanglement."""
        n_qubits = state_data['n_qubits']
        
        # Create a circular layout for qubits
        angles = np.linspace(0, 2*np.pi, n_qubits, endpoint=False)
        x_pos = np.cos(angles)
        y_pos = np.sin(angles)
        
        fig = go.Figure()
        
        # Add qubit nodes
        coherence_values = []
        for i in range(n_qubits):
            coherence = params.get('coherence', {}).get(f'C_{i+1}', 0.8)
            coherence_values.append(coherence)
        
        fig.add_trace(
            go.Scatter(
                x=x_pos, y=y_pos,
                mode='markers+text',
                marker=dict(
                    size=[c*50 + 20 for c in coherence_values],
                    color=coherence_values,
                    colorscale='Viridis',
                    showscale=True,
                    colorbar=dict(title="Coherence"),
                    line=dict(width=2, color='black')
                ),
                text=[f'Q{i+1}' for i in range(n_qubits)],
                textposition="middle center",
                textfont=dict(size=14, color='white'),
                name='Qubits'
            )
        )
        
        # Add entanglement connections
        entanglement = state_data['entanglement']
        
        # For visualization, create connections based on entanglement strength
        for i in range(n_qubits):
            for j in range(i+1, n_qubits):
                # Connection strength based on entanglement and distance
                connection_strength = entanglement * np.exp(-0.5 * abs(i - j))
                
                if connection_strength > 0.1:  # Only show significant connections
                    fig.add_trace(
                        go.Scatter(
                            x=[x_pos[i], x_pos[j]],
                            y=[y_pos[i], y_pos[j]],
                            mode='lines',
                            line=dict(
                                width=connection_strength * 10,
                                color=f'rgba(255, 100, 100, {connection_strength})'
                            ),
                            showlegend=False,
                            hovertemplate=f'Entanglement: {connection_strength:.3f}<extra></extra>'
                        )
                    )
        
        # Add observer time dilation effects as animated circles
        for i in range(n_qubits):
            T_obs = params.get('observer', {}).get(f'T_{i+1}', 1.0)
            radius = 0.2 * T_obs
            
            theta = np.linspace(0, 2*np.pi, 50)
            x_circle = x_pos[i] + radius * np.cos(theta)
            y_circle = y_pos[i] + radius * np.sin(theta)
            
            fig.add_trace(
                go.Scatter(
                    x=x_circle, y=y_circle,
                    mode='lines',
                    line=dict(color='cyan', width=2, dash='dash'),
                    showlegend=False,
                    name=f'Observer {i+1}'
                )
            )
        
        fig.update_layout(
            title='Quantum Entanglement Network',
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            plot_bgcolor='black',
            height=400
        )
        
        return fig
    
    def create_observer_animation(self, state_data: Dict[str, Any], t: float, 
                                 params: Dict[str, Any]) -> go.Figure:
        """Create animated visualization of observer roles."""
        n_qubits = state_data['n_qubits']
        omega_obs = params.get('omega_obs', 1.0)
        
        fig = go.Figure()
        
        # Create observer oscillations
        time_range = np.linspace(0, 4*np.pi, 100)
        
        for i in range(n_qubits):
            T_obs = params.get('observer', {}).get(f'T_{i+1}', 1.0)
            
            # Observer time dilation oscillation
            oscillation = T_obs * np.cos(omega_obs * time_range)
            
            fig.add_trace(
                go.Scatter(
                    x=time_range,
                    y=oscillation,
                    mode='lines',
                    name=f'Observer {i+1}',
                    line=dict(color=self.color_palette[i], width=3)
                )
            )
            
            # Current time marker
            current_oscillation = T_obs * np.cos(omega_obs * t)
            fig.add_trace(
                go.Scatter(
                    x=[t % (4*np.pi)],
                    y=[current_oscillation],
                    mode='markers',
                    marker=dict(size=15, color=self.color_palette[i]),
                    showlegend=False
                )
            )
        
        # Add vertical line for current time
        fig.add_vline(
            x=t % (4*np.pi),
            line_dash="dash",
            line_color="white",
            annotation_text=f"t = {t:.2f}"
        )
        
        fig.update_layout(
            title='Observer Time Dilation Effects',
            xaxis_title='Time',
            yaxis_title='T(t) - Time Dilation Factor',
            plot_bgcolor='black',
            paper_bgcolor='black',
            font_color='white',
            height=300
        )
        
        return fig
    
    def create_emf_field_plot(self, t: float, params: Dict[str, Any]) -> go.Figure:
        """Create EMF field visualization."""
        A_em = params.get('A_em', 0.5)
        omega_em = params.get('omega_em', 2.0)
        
        # Create 2D EMF field
        x = np.linspace(-2, 2, 20)
        y = np.linspace(-2, 2, 20)
        X, Y = np.meshgrid(x, y)
        
        # EMF field components
        Ex = A_em * np.sin(omega_em * t) * np.exp(-(X**2 + Y**2)/4)
        Ey = A_em * np.cos(omega_em * t) * np.exp(-(X**2 + Y**2)/4)
        
        fig = go.Figure()
        
        # Vector field
        fig.add_trace(
            go.Scatter(
                x=X.flatten(),
                y=Y.flatten(),
                mode='markers',
                marker=dict(
                    size=5,
                    color=np.sqrt(Ex.flatten()**2 + Ey.flatten()**2),
                    colorscale='Plasma',
                    showscale=True,
                    colorbar=dict(title="Field Strength")
                ),
                name='EMF Field'
            )
        )
        
        # Add field lines
        skip = 2
        fig.add_trace(
            go.Scatter(
                x=X[::skip, ::skip].flatten(),
                y=Y[::skip, ::skip].flatten(),
                mode='markers',
                marker=dict(
                    size=15,
                    symbol='arrow',
                    angle=np.arctan2(Ey[::skip, ::skip], Ex[::skip, ::skip]).flatten() * 180/np.pi,
                    color='white'
                ),
                showlegend=False
            )
        )
        
        # Current field strength indicator
        current_strength = A_em * np.abs(np.sin(omega_em * t))
        
        fig.update_layout(
            title=f'EMF Field (Strength: {current_strength:.3f})',
            xaxis_title='X',
            yaxis_title='Y',
            plot_bgcolor='black',
            height=300,
            annotations=[
                dict(
                    x=0.02, y=0.98,
                    xref='paper', yref='paper',
                    text=f'ω_em = {omega_em:.1f}, A_em = {A_em:.1f}',
                    showarrow=False,
                    font=dict(color='white')
                )
            ]
        )
        
        return fig
